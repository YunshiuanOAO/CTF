#!/bin/sh

exec 2>/dev/null
cd /home/base64encoder
timeout 60 /home/base64encoder/base64encoder